package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.


import javax.swing.*;
import net.e175.klaus.solarpositioning.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.ZonedDateTime;
import javax.imageio.ImageIO;

public class SolarPositionApp {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            createAndShowGUI();
        });
    }

    private static void createAndShowGUI() {
        // Detect all available screens
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice[] screens = ge.getScreenDevices();

        // If you have more than one screen, choose the one you want to display the JFrame on.
        // For example, to display on the second screen (if available), you can use screens[1].
        int screenIndex = 0; // Change this index as needed

        if (screenIndex < screens.length) {
            GraphicsDevice screen = screens[screenIndex];
            GraphicsConfiguration config = screen.getDefaultConfiguration();

            JFrame frame = new JFrame(config);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(500, 250);

            BackgroundPanel panel = new BackgroundPanel(); // Use our custom JPanel for the background

            frame.add(panel);
            frame.setVisible(true);
        } else {
            // Handle the case when the specified screen index is out of range
            System.out.println("Screen index out of range.");
        }
    }

    // Custom JPanel for the background image
    static class BackgroundPanel extends JPanel {
        private BufferedImage background;
        private String azimuthAngle = "Azimuth Angle: ";
        private String zenithAngle = "Zenith Angle: ";

        private JTextField latitudeField;
        private JTextField longitudeField;
        private JTextField elevationField;

        public BackgroundPanel() {
            setLayout(null); // Use null layout for custom component placement

            // Load your background image
            try {
                background = ImageIO.read(new File("sun_img.png")); // Change the image path
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Create input fields
            latitudeField = new JTextField();
            longitudeField = new JTextField();
            elevationField = new JTextField();
            JLabel wl = new JLabel("Solar Position Calculator");
            wl.setBounds(15,10,250,25);
            wl.setFont(new Font("serif",Font.PLAIN,25));
            add(wl);

            JLabel xl = new JLabel("Latitude:");
            xl.setBounds(30,55,150,25);
            xl.setFont(new Font("serif",Font.PLAIN,20));
            add(xl);

            JLabel yl = new JLabel("Longitude:");
            yl.setBounds(30,85,150,25);
            yl.setFont(new Font("serif",Font.PLAIN,20));
            add(yl);

            JLabel zl = new JLabel("Elevation:");
            zl.setBounds(30,115,150,25);
            zl.setFont(new Font("serif",Font.PLAIN,20));
            add(zl);
            JButton calculateButton = new JButton("Calculate");

            // Position and size of input fields and button
            int x = 130;
            int y = 60;
            int fieldWidth = 100;
            int fieldHeight = 20;
            int spacing = 5;

            latitudeField.setBounds(x, y, fieldWidth, fieldHeight);
            y += fieldHeight + spacing;
            longitudeField.setBounds(x, y, fieldWidth, fieldHeight);
            y += fieldHeight + spacing;
            elevationField.setBounds(x, y, fieldWidth, fieldHeight);
            y += fieldHeight + spacing;
            calculateButton.setBounds(x, y, fieldWidth, fieldHeight);

            // Add components to the panel
            add(latitudeField);
            add(longitudeField);
            add(elevationField);
            add(calculateButton);

            calculateButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        double latitude = Double.parseDouble(latitudeField.getText());
                        double longitude = Double.parseDouble(longitudeField.getText());
                        double elevation = Double.parseDouble(elevationField.getText());

                        ZonedDateTime dateTime = ZonedDateTime.now();

                        SolarPosition position = SPA.calculateSolarPosition(
                                dateTime, latitude, longitude, elevation,
                                DeltaT.estimate(dateTime.toLocalDate()), 954, 25);

                        azimuthAngle = "Azimuth Angle: " + position.azimuth();
                        zenithAngle = "Zenith Angle: " + position.zenithAngle();

                        repaint();
                    } catch (NumberFormatException ex) {
                        azimuthAngle = "Azimuth Angle: ";
                        zenithAngle = "Zenith Angle: ";
                        repaint();
                    }
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (background != null) {
                // Paint the background image
                g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
            }

            // Display azimuth and zenith angles on the background panel
            g.drawString(azimuthAngle, 270, 90);
            g.drawString(zenithAngle, 270, 110);
        }
    }
}

