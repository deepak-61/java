package org.example;

import java.util.*;

public class practice5{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> tp = new ArrayList<>();
        System.out.println("Enter the numbers to be entered in the arraylist: ");
        for(int i=0; i<4; i++){
         int    j = sc.nextInt();
         tp.add(j);
        }
        Collections.sort(tp);
        //iterator loop
        System.out.println("Iterator Loop");
        Iterator<Integer> iterator = tp.iterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }
        // advaced for loop
        System.out.println("Advanced for loop");
        for(int number: tp){
            System.out.println(number);
        }
        //for loop
        System.out.println("For Loop");
        for(int j=0; j<4;j++){
            System.out.println(tp.get(j));

        }






    }

}
